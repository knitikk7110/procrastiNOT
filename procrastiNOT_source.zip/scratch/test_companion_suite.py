"""
test_companion_suite.py
Automated test suite for procrastiNOT.exe Living Cyberpunk RPG Companion System:
- Sprite asset verification (Nex, Glitch, Zero)
- Texture cache & asset manager integrity
- Prerecorded dialogue pools & anti-repetition engine
- CompanionWidget state machine (idle, react, celebrate)
- Hover & touch event handling
- Game event hooks (quest start/complete, XP, streak, achievements)
- Operator selection & persistence
"""

import os
import sys
import json
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

os.environ["KIVY_NO_ARGS"] = "1"
os.environ["KIVY_AUDIO"] = "dummy"

import companion
import main_leaderboard

print("==================================================")
print("RUNNING COMPANION SYSTEM TEST SUITE")
print("==================================================")

# --- TEST 1: Sprite Asset Verification ---
print("\n[TEST 1] Verifying Sprite Assets for NEX, GLITCH, and ZERO...")
CHAR_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "characters")

for char_id in ("nex", "glitch", "zero"):
    char_path = os.path.join(CHAR_DIR, char_id)
    assert os.path.isdir(char_path), f"Character directory missing: {char_path}"
    
    # Check idle frames
    for i in range(4):
        f = os.path.join(char_path, f"idle_{i}.png")
        assert os.path.exists(f) and os.path.getsize(f) > 0, f"Missing {f}"
    
    # Check react frames
    for i in range(3):
        f = os.path.join(char_path, f"react_{i}.png")
        assert os.path.exists(f) and os.path.getsize(f) > 0, f"Missing {f}"
        
    # Check celebrate frames
    for i in range(4):
        f = os.path.join(char_path, f"celebrate_{i}.png")
        assert os.path.exists(f) and os.path.getsize(f) > 0, f"Missing {f}"
        
    # Check preview
    f = os.path.join(char_path, "preview.png")
    assert os.path.exists(f) and os.path.getsize(f) > 0, f"Missing {f}"
    
    print(f"  ✓ {char_id.upper()} has all 12 animation frames + preview portrait verified on disk.")


# --- TEST 2: Texture Cache ---
print("\n[TEST 2] Verifying CompanionAssetManager Texture Loading & Caching...")
tex1 = companion.CompanionAssetManager.get_texture("nex", "idle", 0)
assert tex1 is not None, "Failed to load nex idle_0 texture"
tex1_cached = companion.CompanionAssetManager.get_texture("nex", "idle", 0)
assert tex1 is tex1_cached, "Texture cache should return same instance"
print("  ✓ AssetManager correctly loads and caches textures in memory.")


# --- TEST 3: Dialogue Pools & Anti-Repetition ---
print("\n[TEST 3] Verifying Dialogue Pools & Offline Sarcastic Responses...")
required_cats = [
    "first_launch", "welcome", "idle", "hover", "tap",
    "quest_started", "quest_completed", "quest_failed",
    "xp_gained", "streak_milestone", "achievement_unlocked",
    "return_after_inactivity", "settings_interaction"
]

for char_id, info in companion.OPERATORS.items():
    dialogues = info["dialogues"]
    for cat in required_cats:
        assert cat in dialogues, f"Operator {char_id} missing dialogue category: {cat}"
        assert len(dialogues[cat]) > 0, f"Empty dialogue category {cat} in {char_id}"
        for line in dialogues[cat]:
            assert not line.startswith("[b]") and not line.startswith("[color="), f"Raw markup found in line: {line}"
    print(f"  ✓ {info['name']} ({info['title']}) dialogue pools validated across {len(required_cats)} categories.")


# --- TEST 4: App Integration & CompanionWidget Lifecycle ---
print("\n[TEST 4] Testing App CompanionWidget & Event Reactions...")
test_data_path = os.path.join(tempfile.gettempdir(), "test_companion_save.json")

# Clean mock app state
app = main_leaderboard.ProcrastiNotApp()
app.data_file = test_data_path
app.show_celebration = lambda msg: None
app.refresh_screen = lambda: None
app.play_sound = lambda snd: None
app.set_mascot = lambda m: None
app.emoji_rain = lambda *a, **k: None

# Save initial state with empty companion
with open(test_data_path, "w", encoding="utf-8") as f:
    json.dump({"xp": 50, "missions": [], "selected_companion": ""}, f)

app.load_data()
assert app.selected_companion == "", "Initial companion should be empty"

# Instantiate CompanionWidget
comp_widget = companion.CompanionWidget(app=app)
assert comp_widget.char_id == "nex", "Default fallback operator should be Nex"
print("  ✓ CompanionWidget initialized with default operator.")

# Test state changes
comp_widget.play_state("react", duration=1.0, frames=3)
assert comp_widget.current_state == "react", "State should be react"

comp_widget.play_state("celebrate", duration=1.0, frames=4)
assert comp_widget.current_state == "celebrate", "State should be celebrate"

# Test Tap interaction
comp_widget.on_companion_tapped()
assert comp_widget.current_state == "react", "Tapping should trigger react state"
assert comp_widget.bubble.label.text != "...", "Speech bubble should display dialogue on tap"
print("  ✓ Tap interaction correctly triggered reaction and dialogue:", comp_widget.bubble.label.text)

# Test Hover interaction
comp_widget.on_hover_enter()
assert comp_widget.bubble.label.text != "", "Hover should trigger hover dialogue"
print("  ✓ Hover interaction correctly triggered hover dialogue:", comp_widget.bubble.label.text)

# Test Game Events
comp_widget.on_game_event("quest_started")
print("  ✓ Event 'quest_started' triggered dialogue:", comp_widget.bubble.label.text)

comp_widget.on_game_event("quest_completed")
assert comp_widget.current_state == "celebrate", "Quest completion must trigger celebrate animation"
print("  ✓ Event 'quest_completed' triggered celebrate state and dialogue:", comp_widget.bubble.label.text)

comp_widget.on_game_event("achievement_unlocked")
assert comp_widget.current_state == "celebrate", "Achievement unlock must trigger celebrate animation"
print("  ✓ Event 'achievement_unlocked' triggered celebrate state.")


# --- TEST 5: Operator Switching & Data Persistence ---
print("\n[TEST 5] Testing Operator Selection & Persistence Across Restarts...")
app.companion_widget = comp_widget

# Switch operator to ZERO
app.set_selected_companion("zero")
assert app.selected_companion == "zero", "App selected_companion should be zero"
assert comp_widget.char_id == "zero", "Widget should be updated to zero"
assert "[ZERO // ONLINE]" in comp_widget.name_tag.text, "Name tag should display ZERO"
print("  ✓ Switched operator to ZERO: Widget updated dynamically.")

# Check persistence by reloading from disk
app2 = main_leaderboard.ProcrastiNotApp()
app2.data_file = test_data_path
app2.load_data()
assert app2.selected_companion == "zero", "Persisted companion must be zero after reload"
print("  ✓ Persisted companion selection successfully survived app restart.")

# Switch operator to GLITCH
app.set_selected_companion("glitch")
assert app.selected_companion == "glitch"
assert comp_widget.char_id == "glitch"
print("  ✓ Switched operator to GLITCH: Widget updated dynamically.")

# Cleanup widget and temp file
comp_widget.cleanup()
if os.path.exists(test_data_path):
    os.remove(test_data_path)

print("\n==================================================")
print("ALL COMPANION TESTS PASSED SUCCESSFULLY! (100% GREEN)")
print("==================================================")
