"""
generate_companion_sprites.py
Generates crisp, authentic pixel-art character sprite frames for procrastiNOT.exe:
- NEX (The Hacker): Neon purple jacket, cyan visor, spiky hair, cyberdeck
- GLITCH (The Rebel): Electric blue hair, street rebel outfit, cybernetic arm
- ZERO (The Android): Dark obsidian metallic chassis, mint visor slit, floating shoulder modules

Each character gets:
- idle_0.png .. idle_3.png
- react_0.png .. react_2.png
- celebrate_0.png .. celebrate_3.png
- preview.png
"""

import os
from PIL import Image, ImageDraw

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CHAR_DIR = os.path.join(BASE_DIR, "assets", "characters")

# Canvas is 36x36 native pixels, scaled 4x with nearest-neighbor to 144x144 for crisp HD pixel art
GRID_W, GRID_H = 36, 36
SCALE = 4


def create_canvas():
    return Image.new("RGBA", (GRID_W, GRID_H), (0, 0, 0, 0))


def save_sprite(img, out_path):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    scaled = img.resize((GRID_W * SCALE, GRID_H * SCALE), Image.Resampling.NEAREST)
    scaled.save(out_path)
    print(f"Saved: {out_path} ({scaled.size[0]}x{scaled.size[1]})")


# --------------------------------------------------------------------------
# 1. NEX THE HACKER
# --------------------------------------------------------------------------
def draw_nex_frame(frame_type="idle", frame_idx=0):
    img = create_canvas()
    d = ImageDraw.Draw(img)

    # Base coordinates
    dy = 0
    if frame_type == "idle":
        dy = 1 if frame_idx in (1, 2) else 0
    elif frame_type == "celebrate":
        dy = -3 if frame_idx == 1 else (-4 if frame_idx == 2 else (-1 if frame_idx == 0 else 0))
    elif frame_type == "react":
        dy = 1 if frame_idx == 1 else 0

    # Colors
    c_shadow = (18, 6, 36, 160)
    c_skin = (255, 218, 185, 255)
    c_skin_dark = (222, 178, 145, 255)
    c_hair = (255, 0, 128, 255)
    c_hair_dark = (180, 0, 90, 255)
    c_hair_high = (255, 128, 192, 255)
    c_jacket = (74, 20, 140, 255)
    c_jacket_dark = (42, 10, 92, 255)
    c_jacket_neon = (156, 39, 176, 255)
    c_cyan = (0, 229, 255, 255)
    c_cyan_bright = (190, 255, 255, 255)
    c_pants = (26, 26, 36, 255)
    c_boots = (48, 48, 64, 255)

    # 1. Shadow on ground
    d.ellipse([(11, 31), (25, 34)], fill=c_shadow)

    # 2. Boots & Legs
    leg_y = 24 + dy
    d.rectangle([(13, leg_y), (15, 31)], fill=c_pants)
    d.rectangle([(20, leg_y), (22, 31)], fill=c_pants)
    d.rectangle([(12, 30), (16, 32)], fill=c_boots)
    d.rectangle([(19, 30), (23, 32)], fill=c_boots)
    d.point([(12, 32), (19, 32)], fill=c_cyan)  # Boot neon stripes

    # 3. Torso & Jacket
    d.rectangle([(12, 15 + dy), (23, 24 + dy)], fill=c_jacket)
    d.rectangle([(14, 15 + dy), (21, 23 + dy)], fill=c_jacket_neon)
    d.rectangle([(16, 16 + dy), (19, 24 + dy)], fill=c_jacket_dark)  # Inner shirt
    d.line([(12, 20 + dy), (23, 20 + dy)], fill=c_cyan)  # Neon jacket trim line

    # Cyberdeck slung across chest
    d.line([(13, 16 + dy), (22, 23 + dy)], fill=(120, 120, 140, 255))
    d.rectangle([(18, 20 + dy), (23, 24 + dy)], fill=(20, 20, 30, 255))
    d.point([(19, 21 + dy), (21, 21 + dy), (20, 23 + dy)], fill=c_cyan)  # Deck blinking LEDs

    # 4. Arms
    if frame_type == "celebrate" and frame_idx in (1, 2):
        # Arms raised in victory!
        d.rectangle([(9, 9 + dy), (12, 17 + dy)], fill=c_jacket)
        d.rectangle([(9, 7 + dy), (12, 9 + dy)], fill=c_skin)  # Left fist up
        d.rectangle([(23, 9 + dy), (26, 17 + dy)], fill=c_jacket)
        d.rectangle([(23, 7 + dy), (26, 9 + dy)], fill=c_skin)  # Right fist up
        # Sparkles above
        d.point([(8, 5 + dy), (27, 5 + dy), (18, 3 + dy)], fill=c_cyan_bright)
    elif frame_type == "react":
        # Pointing forward / waving hand
        d.rectangle([(10, 16 + dy), (12, 23 + dy)], fill=c_jacket)
        d.rectangle([(23, 15 + dy), (27, 18 + dy)], fill=c_jacket)
        d.rectangle([(27, 15 + dy), (29, 17 + dy)], fill=c_skin)  # Pointing finger
        d.point([(30, 16 + dy)], fill=c_cyan)  # Hologram spark
    else:
        # Standard idle arms
        d.rectangle([(10, 16 + dy), (12, 23 + dy)], fill=c_jacket)
        d.rectangle([(10, 23 + dy), (12, 25 + dy)], fill=c_skin)
        d.rectangle([(23, 16 + dy), (25, 23 + dy)], fill=c_jacket)
        d.rectangle([(23, 23 + dy), (25, 25 + dy)], fill=c_skin)

    # 5. Head & Neck
    d.rectangle([(16, 13 + dy), (19, 15 + dy)], fill=c_skin_dark)
    d.rectangle([(13, 8 + dy), (22, 14 + dy)], fill=c_skin)

    # Cyber Visor (Cyan Glowing Band)
    visor_color = c_cyan_bright if (frame_idx in (1, 2) and frame_type != "idle") else c_cyan
    d.rectangle([(13, 10 + dy), (22, 12 + dy)], fill=visor_color)
    # Visor scanning glare
    glare_x = 14 + ((frame_idx * 2) % 6)
    d.point([(glare_x, 10 + dy), (glare_x + 1, 10 + dy)], fill=(255, 255, 255, 255))

    # Mouth
    if frame_type == "celebrate":
        d.line([(16, 13 + dy), (19, 13 + dy)], fill=(120, 20, 40, 255))  # Open smile
    elif frame_type == "react":
        d.point([(18, 13 + dy), (19, 13 + dy)], fill=c_skin_dark)  # Smirk
    else:
        d.point([(17, 13 + dy)], fill=c_skin_dark)

    # 6. Spiky Cyberpunk Hair
    d.polygon([(11, 8 + dy), (13, 3 + dy), (16, 6 + dy), (18, 2 + dy),
               (21, 5 + dy), (24, 3 + dy), (24, 9 + dy), (12, 9 + dy)], fill=c_hair)
    d.line([(12, 4 + dy), (15, 6 + dy), (17, 3 + dy), (20, 5 + dy)], fill=c_hair_high)
    d.polygon([(11, 8 + dy), (13, 11 + dy), (12, 13 + dy)], fill=c_hair_dark)  # Side lock
    d.polygon([(24, 8 + dy), (23, 11 + dy), (24, 13 + dy)], fill=c_hair_dark)  # Side lock

    return img


# --------------------------------------------------------------------------
# 2. GLITCH THE REBEL
# --------------------------------------------------------------------------
def draw_glitch_frame(frame_type="idle", frame_idx=0):
    img = create_canvas()
    d = ImageDraw.Draw(img)

    dy = 0
    if frame_type == "idle":
        dy = 1 if frame_idx in (1, 2) else 0
    elif frame_type == "celebrate":
        dy = -3 if frame_idx == 1 else (-4 if frame_idx == 2 else (-1 if frame_idx == 0 else 0))
    elif frame_type == "react":
        dy = 1 if frame_idx == 1 else 0

    # Colors
    c_shadow = (10, 16, 32, 160)
    c_skin = (245, 208, 169, 255)
    c_skin_dark = (198, 134, 66, 255)
    c_blue_hair = (0, 176, 255, 255)
    c_blue_dark = (0, 120, 215, 255)
    c_blue_high = (160, 230, 255, 255)
    c_jacket = (28, 28, 40, 255)
    c_red_accent = (255, 42, 85, 255)
    c_cyber_arm = (176, 190, 197, 255)
    c_cyber_arm_glow = (0, 229, 255, 255)
    c_cargo = (45, 45, 60, 255)
    c_boots = (20, 20, 28, 255)

    # Shadow
    d.ellipse([(10, 31), (26, 34)], fill=c_shadow)

    # Cargo Pants & Boots (wide rebel stance)
    leg_y = 23 + dy
    d.rectangle([(11, leg_y), (14, 30)], fill=c_cargo)
    d.rectangle([(21, leg_y), (24, 30)], fill=c_cargo)
    d.point([(14, leg_y + 2), (21, leg_y + 2)], fill=c_red_accent)  # Straps
    d.rectangle([(10, 29), (14, 32)], fill=c_boots)
    d.rectangle([(21, 29), (25, 32)], fill=c_boots)
    d.point([(10, 32), (25, 32)], fill=c_blue_hair)

    # Torso & Street Rebel Vest
    d.rectangle([(13, 14 + dy), (22, 23 + dy)], fill=c_jacket)
    d.rectangle([(15, 15 + dy), (20, 23 + dy)], fill=(230, 230, 240, 255))  # White graphic tee
    d.point([(17, 18 + dy), (18, 18 + dy), (17, 19 + dy)], fill=c_red_accent)  # Rebel logo
    d.rectangle([(12, 14 + dy), (14, 22 + dy)], fill=c_jacket)  # Left lapel
    d.rectangle([(21, 14 + dy), (23, 22 + dy)], fill=c_jacket)  # Right lapel
    d.line([(13, 14 + dy), (13, 22 + dy)], fill=c_red_accent)  # Red collar stripe

    # Arms
    if frame_type == "celebrate" and frame_idx in (1, 2):
        # Cyber arm & normal arm pump
        d.rectangle([(9, 8 + dy), (12, 16 + dy)], fill=c_skin)
        d.rectangle([(22, 8 + dy), (26, 16 + dy)], fill=c_cyber_arm)
        d.line([(24, 8 + dy), (24, 16 + dy)], fill=c_cyber_arm_glow)  # Neon cyber arm glow
        # Fist sparks
        d.point([(23, 6 + dy), (26, 6 + dy), (25, 5 + dy)], fill=c_blue_high)
    elif frame_type == "react":
        # Cyber arm raised in fist pose
        d.rectangle([(10, 16 + dy), (12, 23 + dy)], fill=c_skin)
        d.rectangle([(22, 12 + dy), (26, 17 + dy)], fill=c_cyber_arm)
        d.rectangle([(23, 10 + dy), (26, 13 + dy)], fill=c_cyber_arm_glow)  # Glowing cyber fist
    else:
        # Normal left arm, Cybernetic right arm
        d.rectangle([(10, 15 + dy), (12, 23 + dy)], fill=c_skin)
        d.rectangle([(23, 15 + dy), (25, 23 + dy)], fill=c_cyber_arm)
        d.point([(24, 18 + dy), (24, 21 + dy)], fill=c_cyber_arm_glow)

    # Head & Neck
    d.rectangle([(16, 12 + dy), (19, 14 + dy)], fill=c_skin_dark)
    d.rectangle([(13, 7 + dy), (22, 13 + dy)], fill=c_skin)

    # Eyes & Expressions
    if frame_type == "celebrate":
        # Happy squint eyes: ^ ^
        d.point([(15, 10 + dy), (17, 9 + dy), (19, 9 + dy), (21, 10 + dy)], fill=c_blue_dark)
        d.line([(16, 12 + dy), (19, 12 + dy)], fill=c_red_accent)
    elif frame_type == "react":
        # Fierce focus: one robotic cyan eye, one determined
        d.rectangle([(15, 9 + dy), (16, 10 + dy)], fill=(30, 30, 40, 255))
        d.rectangle([(19, 9 + dy), (21, 10 + dy)], fill=c_cyber_arm_glow)  # Cyan cyber optic eye
        d.point([(20, 9 + dy)], fill=(255, 255, 255, 255))
        d.line([(16, 12 + dy), (19, 12 + dy)], fill=c_skin_dark)
    else:
        # Confident rebel gaze
        d.point([(15, 10 + dy), (16, 10 + dy)], fill=(20, 20, 30, 255))
        d.point([(19, 10 + dy), (20, 10 + dy)], fill=c_cyber_arm_glow)  # Cyber optic
        d.point([(17, 12 + dy)], fill=c_skin_dark)

    # Electric Blue Hair (Side swept with undercut)
    d.polygon([(11, 7 + dy), (12, 2 + dy), (16, 1 + dy), (21, 2 + dy),
               (24, 5 + dy), (22, 8 + dy), (13, 8 + dy)], fill=c_blue_hair)
    d.line([(13, 3 + dy), (17, 2 + dy), (21, 4 + dy)], fill=c_blue_high)
    d.polygon([(11, 6 + dy), (10, 9 + dy), (12, 12 + dy)], fill=c_blue_dark)  # Long rebel fringe
    d.rectangle([(22, 7 + dy), (23, 11 + dy)], fill=(30, 20, 20, 255))  # Shaved undercut

    # Red Bandana / Forehead strap
    d.line([(12, 7 + dy), (23, 7 + dy)], fill=c_red_accent)

    return img


# --------------------------------------------------------------------------
# 3. ZERO THE ANDROID
# --------------------------------------------------------------------------
def draw_zero_frame(frame_type="idle", frame_idx=0):
    img = create_canvas()
    d = ImageDraw.Draw(img)

    dy = 0
    orb_dy = 0
    if frame_type == "idle":
        dy = 1 if frame_idx in (1, 2) else 0
        orb_dy = -1 if frame_idx == 1 else (1 if frame_idx == 3 else 0)
    elif frame_type == "celebrate":
        dy = -4 if frame_idx in (1, 2) else (-2 if frame_idx == 0 else 0)
        orb_dy = -2 if frame_idx == 1 else 2
    elif frame_type == "react":
        dy = 0
        orb_dy = -2 if frame_idx == 1 else 0

    # Colors
    c_shadow = (0, 30, 20, 160)
    c_metal_dark = (26, 32, 44, 255)
    c_metal_mid = (45, 55, 72, 255)
    c_metal_light = (113, 128, 150, 255)
    c_white_armor = (226, 232, 240, 255)
    c_mint = (0, 255, 163, 255)
    c_mint_bright = (200, 255, 235, 255)
    c_core_violet = (213, 0, 249, 255)
    c_gold = (255, 215, 0, 255)

    # Holographic Hover Base / Shadow
    d.ellipse([(9, 31), (27, 34)], fill=c_shadow)
    # Pedestal projection ring
    d.ellipse([(11, 31), (25, 33)], outline=c_mint)

    # Hover Thruster Jets (instead of human legs)
    leg_y = 23 + dy
    d.rectangle([(13, leg_y), (16, 28 + dy)], fill=c_metal_mid)
    d.rectangle([(19, leg_y), (22, 28 + dy)], fill=c_metal_mid)
    d.point([(14, 28 + dy), (21, 28 + dy)], fill=c_gold)
    # Energy thrust plume
    plume_h = 3 if frame_idx % 2 == 0 else 2
    d.polygon([(14, 29 + dy), (15, 29 + dy + plume_h), (16, 29 + dy)], fill=c_mint)
    d.polygon([(20, 29 + dy), (21, 29 + dy + plume_h), (22, 29 + dy)], fill=c_mint)

    # Chassis Torso (Mechanical Angular Armor)
    d.rectangle([(12, 14 + dy), (23, 23 + dy)], fill=c_metal_dark)
    d.rectangle([(14, 15 + dy), (21, 22 + dy)], fill=c_white_armor)
    # Arc Reactor / Central Power Core
    core_color = c_mint_bright if frame_type == "celebrate" else c_mint
    d.ellipse([(16, 17 + dy), (19, 20 + dy)], fill=core_color)
    d.point([(17, 18 + dy), (18, 18 + dy)], fill=(255, 255, 255, 255))
    d.line([(13, 14 + dy), (22, 14 + dy)], fill=c_gold)  # Neck collar seam

    # Arms / Manipulators
    if frame_type == "celebrate" and frame_idx in (1, 2):
        # Robotic arms up in triumphant machine pose
        d.rectangle([(9, 9 + dy), (12, 16 + dy)], fill=c_white_armor)
        d.point([(10, 8 + dy), (11, 8 + dy)], fill=c_mint)  # Emitter tips
        d.rectangle([(23, 9 + dy), (26, 16 + dy)], fill=c_white_armor)
        d.point([(24, 8 + dy), (25, 8 + dy)], fill=c_mint)
        # Digital code particles
        d.point([(7, 5 + dy), (28, 5 + dy), (17, 2 + dy)], fill=c_mint_bright)
    elif frame_type == "react":
        # Scanning posture: arm forward with projector
        d.rectangle([(10, 15 + dy), (12, 22 + dy)], fill=c_metal_mid)
        d.rectangle([(23, 14 + dy), (27, 17 + dy)], fill=c_white_armor)
        d.point([(28, 15 + dy)], fill=c_mint_bright)
        # Hologram scan cone
        d.line([(28, 15 + dy), (34, 11 + dy)], fill=(0, 255, 163, 140))
        d.line([(28, 15 + dy), (34, 19 + dy)], fill=(0, 255, 163, 140))
    else:
        # Standard idle mechanical arms
        d.rectangle([(10, 15 + dy), (12, 22 + dy)], fill=c_white_armor)
        d.point([(11, 22 + dy)], fill=c_gold)
        d.rectangle([(23, 15 + dy), (25, 22 + dy)], fill=c_white_armor)
        d.point([(24, 22 + dy)], fill=c_gold)

    # Robotic Head (Sleek Angular Helmet)
    d.rectangle([(13, 7 + dy), (22, 13 + dy)], fill=c_metal_mid)
    d.polygon([(14, 7 + dy), (18, 4 + dy), (21, 7 + dy)], fill=c_white_armor)  # Crown crest
    d.line([(12, 6 + dy), (12, 4 + dy)], fill=c_gold)  # Antenna left
    d.point([(12, 3 + dy)], fill=c_mint)

    # Visor Slit
    if frame_type == "celebrate":
        # Happy digital eyes ^ ^
        d.point([(15, 9 + dy), (17, 8 + dy), (19, 8 + dy), (21, 9 + dy)], fill=c_mint_bright)
    elif frame_type == "react":
        # Visor wide alert scan
        d.rectangle([(14, 9 + dy), (21, 10 + dy)], fill=c_mint_bright)
        d.point([(17, 9 + dy), (18, 9 + dy)], fill=(255, 255, 255, 255))
    else:
        # Standard glowing mint visor slit
        d.line([(14, 9 + dy), (21, 9 + dy)], fill=c_mint)
        scan_x = 15 + (frame_idx % 4)
        d.point([(scan_x, 9 + dy)], fill=c_mint_bright)

    # Floating Satellite Shoulder Orbs (Signature Android Feature)
    orb_l_y = 13 + dy + orb_dy
    orb_r_y = 13 + dy - orb_dy
    # Left orb
    d.ellipse([(5, orb_l_y), (8, orb_l_y + 3)], fill=c_metal_dark)
    d.point([(6, orb_l_y + 1), (7, orb_l_y + 1)], fill=c_core_violet)
    # Right orb
    d.ellipse([(27, orb_r_y), (30, orb_r_y + 3)], fill=c_metal_dark)
    d.point([(28, orb_r_y + 1), (29, orb_r_y + 1)], fill=c_core_violet)

    return img


# --------------------------------------------------------------------------
# Generate All Sprites
# --------------------------------------------------------------------------
def generate_all():
    characters = [
        ("nex", draw_nex_frame),
        ("glitch", draw_glitch_frame),
        ("zero", draw_zero_frame),
    ]

    for char_id, draw_func in characters:
        char_path = os.path.join(CHAR_DIR, char_id)
        os.makedirs(char_path, exist_ok=True)
        print(f"\n--- Generating {char_id.upper()} Sprites ---")

        # 1. Idle animation (4 frames)
        for i in range(4):
            img = draw_func("idle", i)
            save_sprite(img, os.path.join(char_path, f"idle_{i}.png"))

        # 2. Reaction animation (3 frames)
        for i in range(3):
            img = draw_func("react", i)
            save_sprite(img, os.path.join(char_path, f"react_{i}.png"))

        # 3. Celebrate animation (4 frames)
        for i in range(4):
            img = draw_func("celebrate", i)
            save_sprite(img, os.path.join(char_path, f"celebrate_{i}.png"))

        # 4. Profile preview portrait
        preview_img = draw_func("idle", 0)
        save_sprite(preview_img, os.path.join(char_path, "preview.png"))


if __name__ == "__main__":
    generate_all()
    print("\nAll companion character sprites generated successfully!")
