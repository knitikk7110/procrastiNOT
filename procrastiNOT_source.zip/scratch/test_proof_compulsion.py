"""
test_proof_compulsion.py - Test suite verifying Proof Compulsion enforcement across procrastiNOT.exe
"""
import os
import sys
import json
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import main_leaderboard
from main_leaderboard import ProcrastiNotApp

print("==================================================")
print("TESTING PROOF COMPULSION & ANTI-BYPASS ENFORCEMENT")
print("==================================================")

# 1. Initialize temporary clean state
temp_data = os.path.join(tempfile.gettempdir(), "test_compulsion_data.json")
initial_data = {
    "xp": 200,
    "missions": [
        {
            "name": "Workout 30 mins",
            "criteria": "Photo of treadmill or gym",
            "done": False,
            "priority": "High",
            "created": "2026-10-19"
        },
        {
            "name": "Math Problem Set 4",
            "criteria": "Photo of handwritten equations",
            "done": False,
            "priority": "Normal",
            "created": "2026-10-19"
        }
    ],
    "completed_dates": [],
    "achievements": [],
    "habits": [],
    "arcade_scores": {}
}

with open(temp_data, "w", encoding="utf-8") as f:
    json.dump(initial_data, f)

app = ProcrastiNotApp()
app.data_file = temp_data
app.load_data()
app.refresh_screen = lambda: None
app.play_sound = lambda snd: None
app.show_celebration = lambda msg: None
app.emoji_rain = lambda *a, **k: None

# Intercept open_proof_verification to verify it gets called
opened_modal_indices = []
def mock_open_proof_verification(idx):
    opened_modal_indices.append(idx)
app.open_proof_verification = mock_open_proof_verification

# TEST 1: Direct complete_mission call without proof must be BLOCKED
print("\n[TEST 1] Attempting unverified complete_mission(0)...")
app.complete_mission(0)
assert app.missions[0]["done"] is False, "TEST FAILED: Unverified mission was marked done!"
assert app.xp == 200, f"TEST FAILED: XP was awarded without proof! (XP: {app.xp})"
assert 0 in opened_modal_indices, "TEST FAILED: Proof verification modal was not opened!"
print("  [OK] Proof Compulsion correctly BLOCKED direct completion and redirected to proof verification modal.")

# TEST 2: Verified claim via claim_verified_mission must succeed
print("\n[TEST 2] Claiming mission 0 with approved AI vision verdict...")
approved_verdict = {
    "verdict": "approved",
    "confidence": 0.96,
    "reason": "Clear photo of gym treadmill with 30:00 elapsed time.",
    "evidence_found": ["Treadmill dashboard", "Timer reading 30:00"],
    "missing_evidence": [],
    "model_used": "gemini-3-flash-preview"
}
app.claim_verified_mission(0, approved_verdict)
assert app.missions[0]["done"] is True, "TEST FAILED: Verified mission was not marked done!"
assert app.missions[0]["proof_verified"] is True, "TEST FAILED: proof_verified flag not set!"
assert app.xp == 225, f"TEST FAILED: XP was not awarded after verified proof! (XP: {app.xp})"
print("  [OK] Mission 0 successfully claimed and credited +25 XP with verified AI proof.")

# TEST 3: Focus Chamber complete_active_quest must require proof
print("\n[TEST 3] Testing Focus Chamber complete_active_quest...")
import focus_chamber
fc = focus_chamber.create_focus_screen(app=app)
fc.focus_chamber.selected_quest_name = "Math Problem Set 4"
opened_modal_indices.clear()

fc.focus_chamber.complete_active_quest()
assert app.missions[1]["done"] is False, "TEST FAILED: Focus chamber marked quest done without proof!"
assert app.xp == 225, "TEST FAILED: XP was awarded in focus chamber without proof!"
assert 1 in opened_modal_indices, "TEST FAILED: Focus chamber did not open proof verification modal for target quest!"
print("  [OK] Focus Chamber correctly enforced Proof Compulsion and redirected to proof verification modal.")

# TEST 4: make_mission_row must NOT have a plain 'CLEAR' button
print("\n[TEST 4] Inspecting make_mission_row for mission 1...")
row = app.make_mission_row(1, app.missions[1])
button_texts = []
def scan_buttons(w):
    if hasattr(w, "text"):
        button_texts.append(w.text)
    for c in getattr(w, "children", []):
        scan_buttons(c)
scan_buttons(row)
print("  Buttons found in active quest row:", ascii(button_texts))
assert not any("⚡ CLEAR" in t for t in button_texts), "TEST FAILED: ⚡ CLEAR button still exists in quest row!"
assert any("PROVE" in t for t in button_texts), "TEST FAILED: PROVE button missing from quest row!"
print("  [OK] Verified: Direct CLEAR button is removed, only PROVE & CLEAR button is present.")

# Cleanup
if os.path.exists(temp_data):
    os.remove(temp_data)

print("\n==================================================")
print("ALL PROOF COMPULSION TESTS PASSED WITH 100% SUCCESS!")
print("==================================================")
