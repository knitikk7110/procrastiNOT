"""
Test Suite for Cyber System Commendations & Achievements (28 Badges across 6 Categories)
"""
import os
import sys

# Ensure ProjectX root is on sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from main_leaderboard import ProcrastiNotApp


def test_achievements_system():
    print("=" * 60)
    print("TESTING SYSTEM COMMENDATIONS & ACHIEVEMENTS (28 BADGES)")
    print("=" * 60)

    app = ProcrastiNotApp()
    app.build()

    # 1. Total Badge Count
    badges = app.badge_defs()
    print(f"\n[TEST 1] Verifying total badge count... Found {len(badges)} badges.")
    assert len(badges) == 28, f"Expected 28 badges, got {len(badges)}"

    # 2. Category Distribution
    categories = {}
    rarities = {}
    for b in badges:
        cat = b[3]
        rarity = b[4]
        categories[cat] = categories.get(cat, 0) + 1
        rarities[rarity] = rarities.get(rarity, 0) + 1

    print(f"\n[TEST 2] Category distribution: {categories}")
    assert "missions" in categories and categories["missions"] == 7
    assert "xp" in categories and categories["xp"] == 5
    assert "streaks" in categories and categories["streaks"] == 4
    assert "focus" in categories and categories["focus"] == 6
    assert "arcade" in categories and categories["arcade"] == 4
    assert "biometrics" in categories and categories["biometrics"] == 2

    print(f"Rarity distribution: {rarities}")
    assert rarities.get("COMMON", 0) >= 10
    assert rarities.get("RARE", 0) >= 8
    assert rarities.get("EPIC", 0) >= 4
    assert rarities.get("LEGENDARY", 0) >= 4

    # 3. Test Navigation to Achievements Page
    print("\n[TEST 3] Testing Navigation to Achievements Page...")
    app.go_page("achievements")
    assert app.pages.current == "achievements", "Failed to switch to achievements page!"
    assert hasattr(app, "achievement_label"), "Missing achievement_label!"
    assert hasattr(app, "achievement_xp_label"), "Missing achievement_xp_label!"
    assert hasattr(app, "achievement_bar"), "Missing achievement_bar!"
    assert hasattr(app, "badge_list"), "Missing badge_list container!"

    # 4. Test Category Filtering
    print("\n[TEST 4] Testing Category Filtering...")
    app.set_badge_filter("missions")
    assert app.active_badge_filter == "missions"
    assert len(app.badge_list.children) == 7, f"Expected 7 mission badges, got {len(app.badge_list.children)}"

    app.set_badge_filter("arcade")
    assert app.active_badge_filter == "arcade"
    assert len(app.badge_list.children) == 4, f"Expected 4 arcade badges, got {len(app.badge_list.children)}"

    app.set_badge_filter("ALL")
    assert app.active_badge_filter == "ALL"
    assert len(app.badge_list.children) == 28, f"Expected 28 badges in ALL view, got {len(app.badge_list.children)}"

    # 5. Test Live Card Generation & Progress Tracking
    print("\n[TEST 5] Testing Card Generation for Unlocked and Locked States...")
    unlocked_b = ("🌱 First Quest", "Clear your first mission directive", True, "missions", "COMMON", "1/1 cleared", 1.0, 20)
    card_u = app.make_badge_card(unlocked_b)
    assert card_u is not None, "Failed to render unlocked badge card"

    locked_b = ("🪐 Century Operative (50)", "Clear 50 mission directives", False, "missions", "LEGENDARY", "12/50 cleared", 0.24, 500)
    card_l = app.make_badge_card(locked_b)
    assert card_l is not None, "Failed to render locked badge card"

    print("\n" + "=" * 60)
    print("ALL 5 ACHIEVEMENT TESTS PASSED WITH 100% SUCCESS!")
    print("=" * 60)


if __name__ == "__main__":
    test_achievements_system()
