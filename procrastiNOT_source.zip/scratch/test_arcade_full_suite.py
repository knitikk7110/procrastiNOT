"""
test_arcade_full_suite.py - Automated Verification Suite for Mind Reset Arcade
Tests:
- Screen registration and navigation to 'arcade'
- Home page arcade entry button presence and binding
- Arcade Lobby view and game cabinet cards
- Dedicated Canvas Widget isolation (HUD and UI widgets never wiped)
- Game A: Neon Dodge (live score pointer, steering, STOP button, game over modal, REPLAY)
- Game B: Pixel Pop (timer, live score pointer, combo, STOP BLITZ button, summary modal, REPLAY)
- Game C: Cyber Breaker (retro firewall smasher, paddle, ball physics, score, STOP & REPLAY)
- Game D (Bonus): Calm Breathing Chamber (phases, timer, FINISH SESSION button)
- Audio engine non-blocking safety
- Save & Load integrity (preservation of XP, missions, moods, streaks)
- Clean lifecycle and Clock cleanup when leaving arcade
"""

import os
import sys
import json
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

os.environ["KIVY_NO_ARGS"] = "1"
os.environ["KIVY_AUDIO"] = "dummy"

from kivy.clock import Clock
from kivy.metrics import dp
import main_leaderboard
import arcade


def run_all_tests():
    print("=" * 60)
    print("MIND RESET ARCADE - AUTOMATED TEST SUITE")
    print("=" * 60)

    # 1. Instantiate App and build
    print("\n[TEST 1] Building ProcrastiNotApp...")
    app = main_leaderboard.ProcrastiNotApp()
    app.data_file = os.path.join(os.path.dirname(__file__), "test_save_data.json")

    # Seed initial test data
    test_initial_data = {
        "xp": 420,
        "missions": [{"name": "Complete Math Sheet", "done": False, "priority": "High"}],
        "mood_logs": [{"date": "2026-10-19", "mood": "😎 Focused"}],
        "completed_dates": ["2026-10-18"],
        "sound_enabled": True,
        "arcade_scores": {"neon_dodge": 150, "pixel_pop": 800, "cyber_breaker": 500}
    }
    with open(app.data_file, "w", encoding="utf-8") as f:
        json.dump(test_initial_data, f)

    root_widget = app.build()
    assert root_widget is not None, "App build returned None"
    print("ProcrastiNotApp built successfully!")

    # Verify initial data load
    assert app.xp == 420, f"Expected XP 420, got {app.xp}"
    assert len(app.missions) == 1, "Missions not loaded"
    assert app.arcade_scores["neon_dodge"] == 150, "Arcade scores not loaded"
    print("Existing user data (XP, missions, mood) loaded and intact.")

    # 2. Test Navigation to Arcade
    print("\n[TEST 2] Testing Navigation to Arcade...")
    assert app.pages.has_screen("arcade"), "Arcade screen is not registered in ScreenManager!"
    assert "arcade" in app.nav_buttons, "Arcade nav button missing from sidebar!"

    app.go_page("arcade")
    assert app.pages.current == "arcade", f"Failed to switch to arcade, current={app.pages.current}"
    assert "// MIND RESET ARCADE" in app.header_title.text, f"Unexpected header title: {app.header_title.text}"
    print("Navigation to Arcade verified! Header title updated.")

    arcade_screen = app.arcade_screen
    assert arcade_screen is not None, "Arcade screen instance is None"
    assert arcade_screen.current_view == "lobby", f"Initial view should be lobby, got {arcade_screen.current_view}"

    # 3. Test Game A: Neon Dodge
    print("\n[TEST 3] Testing Game A: Neon Dodge...")
    arcade_screen.size = (800, 600)
    arcade_screen.switch_view("neon_dodge")
    assert arcade_screen.current_view == "neon_dodge"
    dodge_game = arcade_screen.neon_dodge
    dodge_game.size = (800, 600)

    # Check dedicated canvas isolation
    assert hasattr(dodge_game, "game_canvas"), "Neon Dodge missing dedicated game_canvas!"
    child_count_before = len(dodge_game.children)

    # Start game
    dodge_game.start_game()
    assert dodge_game.is_running is True, "Neon Dodge failed to start"
    assert dodge_game.score == 0

    # Simulate game ticks
    for _ in range(30):
        dodge_game._tick(1.0 / 60.0)

    # Check HUD scoreboard is live and updating
    assert dodge_game.score > 0, f"Score should increment over time, got {dodge_game.score}"
    assert "SCORE: [" in dodge_game.score_lbl.text, f"Score pointer not formatted properly: {dodge_game.score_lbl.text}"
    assert len(dodge_game.children) == child_count_before, "UI widgets were wiped by redraw!"
    assert dodge_game.stop_btn is not None, "STOP GAME button is missing from HUD!"

    # Test player steering
    orig_x = dodge_game.player_x
    dodge_game.keys_down.add("left")
    dodge_game._tick(0.1)
    assert dodge_game.player_x < orig_x, "Left steering failed"

    dodge_game.keys_down.clear()
    dodge_game.keys_down.add("right")
    dodge_game._tick(0.2)
    assert dodge_game.player_x > orig_x * 0.9, "Right steering failed"
    dodge_game.keys_down.clear()

    # Test STOP GAME button
    dodge_game.stop_game_action()
    assert dodge_game.is_running is False, "Game should stop when stop button clicked"
    assert dodge_game.game_over_panel.opacity == 1, "Game over / summary panel should be visible"
    assert "RUN TERMINATED" in dodge_game.go_title.text or "SPRINT TERMINATED" in dodge_game.go_title.text
    assert dodge_game.retry_btn is not None, "Replay button missing from game over modal!"

    # Test REPLAY button
    dodge_game.retry_btn.on_click()
    assert dodge_game.is_running is True, "Replay button failed to restart game!"
    assert dodge_game.game_over_panel.opacity == 0, "Game over panel should hide on replay"
    dodge_game.stop_loop()
    print("Neon Dodge live score pointer, STOP button, game over modal, and REPLAY verified!")

    # 4. Test Game B: Pixel Pop
    print("\n[TEST 4] Testing Game B: Pixel Pop...")
    arcade_screen.switch_view("pixel_pop")
    assert arcade_screen.current_view == "pixel_pop"
    pop_game = arcade_screen.pixel_pop
    pop_game.size = (800, 600)

    assert hasattr(pop_game, "game_canvas"), "Pixel Pop missing dedicated game_canvas!"
    assert pop_game.stop_btn is not None, "STOP BLITZ button is missing from HUD!"

    pop_game.start_game()
    assert pop_game.is_running is True, "Pixel Pop failed to start"
    assert pop_game.time_left == 30.0

    # Add mock target and pop it
    pop_game.targets.append({
        "x": 0.5, "y": 0.5, "size": 40, "type": "cyan",
        "color": (0, 0.88, 1, 1), "points": 100, "life": 0.0, "max_life": 3.0, "pulse": 0.0
    })
    target_to_pop = pop_game.targets[0]
    pop_game._pop_target(target_to_pop)

    assert pop_game.score >= 100, f"Expected score >= 100, got {pop_game.score}"
    assert "SCORE: [" in pop_game.score_lbl.text, f"Score pointer not formatted properly: {pop_game.score_lbl.text}"
    assert pop_game.popped_count == 1
    assert len(pop_game.particles) > 0, "Pop explosion particles should generate"
    assert len(pop_game.popups) > 0, "Floating score popup should generate"

    # Test STOP BLITZ button
    pop_game.stop_round_action()
    assert pop_game.is_running is False, "Pixel Pop should finish when STOP button clicked"
    assert pop_game.results_panel.opacity == 1, "Results panel should be visible"
    assert pop_game.play_again_btn is not None, "Replay button missing from results panel!"

    # Test REPLAY button
    pop_game.play_again_btn.on_click()
    assert pop_game.is_running is True, "Replay button failed to restart blitz round!"
    assert pop_game.results_panel.opacity == 0, "Results panel should hide on replay"
    pop_game.stop_loop()
    print("Pixel Pop live score pointer, timer, STOP BLITZ button, results modal, and REPLAY verified!")

    # 5. Test Game C: Cyber Breaker (Replaced Memory Glitch)
    print("\n[TEST 5] Testing Game C: Cyber Breaker...")
    arcade_screen.switch_view("cyber_breaker")
    assert arcade_screen.current_view == "cyber_breaker"
    breaker_game = arcade_screen.cyber_breaker
    breaker_game.size = (800, 600)

    assert hasattr(breaker_game, "game_canvas"), "Cyber Breaker missing dedicated game_canvas!"
    assert breaker_game.stop_btn is not None, "STOP GAME button is missing from Cyber Breaker HUD!"
    assert breaker_game.pause_btn is not None, "PAUSE button is missing from Cyber Breaker HUD!"
    assert breaker_game.score_lbl is not None, "Score pointer missing from HUD!"
    assert breaker_game.lives_lbl is not None, "Lives counter missing from HUD!"
    assert breaker_game.bricks_lbl is not None, "Blocks counter missing from HUD!"

    # Start game (immediately launches ball upward)
    breaker_game.start_game()
    assert breaker_game.is_running is True, "Cyber Breaker failed to start"
    assert breaker_game.lives == 3, f"Expected 3 lives, got {breaker_game.lives}"
    assert len(breaker_game.bricks) == 28, f"Expected 28 firewall bricks, got {len(breaker_game.bricks)}"
    assert breaker_game.ball_attached is False, "Ball should launch immediately on game start"

    # Test paddle steering
    orig_paddle = breaker_game.paddle_x
    breaker_game.keys_down.add("left")
    breaker_game._tick(0.1)
    assert breaker_game.paddle_x < orig_paddle, "Paddle left movement failed"

    breaker_game.keys_down.clear()
    breaker_game.keys_down.add("right")
    breaker_game._tick(0.2)
    assert breaker_game.paddle_x > orig_paddle * 0.9, "Paddle right movement failed"
    breaker_game.keys_down.clear()

    # Simulate brick collision
    target_brick = breaker_game.bricks[0]
    w = breaker_game.width
    h = breaker_game.height
    bx = target_brick["rel_x"] * w
    by = h - dp(75) - target_brick["r_idx"] * dp(24)
    bw = target_brick["rel_w"] * w
    bh = dp(18)
    breaker_game.ball_x = bx + bw / 2
    breaker_game.ball_y = by + bh / 2
    breaker_game.ball_vx = 0
    breaker_game.ball_vy = 100
    breaker_game._tick(0.001)

    assert target_brick["alive"] is False, "Brick should shatter on ball impact"
    assert breaker_game.score > 0, "Score should increase when brick is smashed"
    assert "SCORE: [" in breaker_game.score_lbl.text, f"Score pointer not updating: {breaker_game.score_lbl.text}"
    assert len(breaker_game.particles) > 0, "Explosion particles should generate on brick shatter"

    # Test STOP GAME button
    breaker_game.stop_game_action()
    assert breaker_game.is_running is False, "Game should stop when STOP button clicked"
    assert breaker_game.game_over_panel.opacity == 1, "Game over modal should be visible"
    assert breaker_game.retry_btn is not None, "Replay button missing from game over modal!"

    # Test REPLAY button
    breaker_game.retry_btn.on_click()
    assert breaker_game.is_running is True, "Replay button failed to restart Cyber Breaker"
    assert breaker_game.game_over_panel.opacity == 0, "Game over modal should hide on replay"
    breaker_game.stop_loop()
    print("Cyber Breaker live score pointer, paddle controls, brick shattering, STOP button, and REPLAY verified!")

    # 6. Test Game D: Calm Breathing Chamber
    print("\n[TEST 6] Testing Calm Breathing Chamber...")
    arcade_screen.switch_view("calm_mode")
    assert arcade_screen.current_view == "calm_mode"
    calm = arcade_screen.calm_chamber
    calm.size = (800, 600)

    assert hasattr(calm, "bg_canvas"), "Calm Chamber missing dedicated bg_canvas!"
    assert calm.finish_btn is not None, "FINISH SESSION button missing from Calm Chamber!"

    # Tick breathing cycle
    calm._tick(1.0)
    assert calm.session_seconds >= 1.0
    assert "MINDFUL TIME:" in calm.timer_lbl.text
    assert calm.phase_lbl.text != ""
    print("Calm Breathing Chamber phase ticks, mindful timer, and finish button verified!")

    # 7. Test Return to Base (Home) & Clean Lifecycle
    print("\n[TEST 7] Testing Return to Base & Lifecycle Cleanup...")
    arcade_screen.go_back_to_base()
    assert app.pages.current == "home", f"Failed to return to home, current={app.pages.current}"
    assert dodge_game._loop_event is None, "Neon Dodge loop timer not cleaned up!"
    assert pop_game._loop_event is None, "Pixel Pop loop timer not cleaned up!"
    assert breaker_game._loop_event is None, "Cyber Breaker loop timer not cleaned up!"
    assert calm._tick_event is None, "Calm Chamber tick timer not cleaned up!"
    print("Return to Base and Clock interval cleanup verified with zero leaks!")

    # 8. Test Data Persistence & XP Safety
    print("\n[TEST 8] Testing Data Persistence & XP Safety...")
    app.arcade_scores["neon_dodge"] = 999
    app.arcade_scores["pixel_pop"] = 1250
    app.arcade_scores["cyber_breaker"] = 2400
    app.save_data()

    # Re-read JSON file directly
    with open(app.data_file, "r", encoding="utf-8") as f:
        saved_data = json.load(f)

    assert saved_data["xp"] == 420, f"XP corrupted! Expected 420, got {saved_data.get('xp')}"
    assert len(saved_data["missions"]) == 1, "Missions list corrupted!"
    assert saved_data["arcade_scores"]["neon_dodge"] == 999, "Arcade scores not persisted!"
    assert saved_data["arcade_scores"]["pixel_pop"] == 1250, "Arcade scores not persisted!"
    assert saved_data["arcade_scores"]["cyber_breaker"] == 2400, "Arcade scores not persisted!"
    print("Data persistence verified! XP, missions, moods, and arcade scores are completely safe.")

    # 9. Test Audio Synthesis (Non-blocking, Windows native)
    print("\n[TEST 9] Testing Audio Engine...")
    arcade.ArcadeAudio.play("pop", True)
    arcade.ArcadeAudio.play("level_up", True)
    arcade.ArcadeAudio.play("crash", False)  # respects muted
    print("Audio engine calls executed without blocking or error.")

    # 10. Test Cyber Focus Chamber (Pomodoro Deep Work)
    print("\n[TEST 10] Testing Cyber Focus Chamber...")
    assert app.pages.has_screen("focus"), "Focus Chamber screen is not registered!"
    assert "focus" in app.nav_buttons, "Focus Chamber button missing from sidebar!"
    app.go_page("focus")
    assert app.pages.current == "focus", f"Failed to switch to focus, current={app.pages.current}"
    assert "// CYBER FOCUS CHAMBER" in app.header_title.text, f"Unexpected header title: {app.header_title.text}"

    focus_chamber = app.focus_screen.focus_chamber
    assert focus_chamber is not None, "CyberFocusChamber instance is None"
    # Test preset
    focus_chamber.set_preset(15, 3)
    assert focus_chamber.focus_duration == 15 * 60
    assert focus_chamber.time_left == 15 * 60
    # Test timer engage
    focus_chamber.toggle_timer()
    assert focus_chamber.state == "FOCUS"
    focus_chamber._tick(1.0)
    assert focus_chamber.time_left == (15 * 60) - 1
    # Test sprint finish & reward flow
    initial_xp = app.xp
    focus_chamber._on_phase_finished()
    assert app.xp >= initial_xp + 50, f"Expected +50 XP bonus, got {app.xp - initial_xp}"
    assert focus_chamber.modal_panel.opacity == 1, "Completion modal should be visible"
    focus_chamber.stop_loop()
    print("Cyber Focus Chamber presets, countdown, and +50 XP sprint reward verified!")

    # 11. Test Cyber Habit Matrix (Daily Routines, Streaks & Shield)
    print("\n[TEST 11] Testing Cyber Habit Matrix...")
    assert app.pages.has_screen("habits"), "Cyber Habit Matrix screen is not registered!"
    assert "habits" in app.nav_buttons, "Cyber Habit Matrix button missing from sidebar!"
    app.go_page("habits")
    assert app.pages.current == "habits", f"Failed to switch to habits, current={app.pages.current}"
    assert "// CYBER HABIT MATRIX" in app.header_title.text, f"Unexpected header title: {app.header_title.text}"

    habit_matrix = app.habits_screen.habit_matrix
    assert habit_matrix is not None, "CyberHabitMatrix instance is None"
    assert len(habit_matrix.habits) >= 5, f"Expected default habits, got {len(habit_matrix.habits)}"

    # Test habit checkoff awards genuine +10 XP and increases shield
    initial_xp = app.xp
    h0 = habit_matrix.habits[0]
    initial_streak = h0.get("streak", 0)
    habit_matrix.toggle_habit(h0["id"])
    assert h0["completed_today"] is True, "Habit should be completed today after toggle"
    assert h0["streak"] == initial_streak + 1, "Streak should increase on habit completion"
    assert app.xp == initial_xp + 10, f"Expected +10 XP bonus earned for habit checkoff, got {app.xp - initial_xp}"
    assert habit_matrix.shield_percent > 0, "Daily armor shield should increase after checking off habit"

    # Test adding a custom routine
    prev_count = len(habit_matrix.habits)
    habit_matrix.add_custom_habit("⚡", "Electrolyte Hydration & Core Stretches")
    assert len(habit_matrix.habits) == prev_count + 1, "Custom habit was not added to matrix!"
    assert habit_matrix.habits[-1]["name"] == "Electrolyte Hydration & Core Stretches"
    print("Cyber Habit Matrix daily routines, streak progression, earned +10 XP, and armor shield verified!")

    # 12. Test Home Command Deck: Quick-Deploy Quest Terminal & 30-Day Heatmap
    print("\n[TEST 12] Testing Home Command Deck Quick-Deploy & 30-Day Heatmap...")
    app.go_page("home")
    assert hasattr(app, "quick_quest_input"), "quick_quest_input missing from app!"
    assert hasattr(app, "activity_heatmap"), "activity_heatmap missing from app!"

    # Test Quick-Deploy
    initial_mission_count = len(app.missions)
    initial_xp = app.xp
    app.quick_quest_input.text = "Infiltrate Quantum Database"
    app.quick_deploy_quest()
    assert len(app.missions) == initial_mission_count + 1, "Quick-deployed quest not added to missions!"
    assert app.missions[-1]["name"] == "Infiltrate Quantum Database", "Quest name mismatch!"
    assert app.xp == initial_xp + 15, f"Expected +15 XP for quick deploy, got {app.xp - initial_xp}"

    # Test 30-Day Heatmap
    app.activity_heatmap.refresh()
    assert len(app.activity_heatmap.cells) == 30, "Activity heatmap must have 30 cells!"
    assert "CONSISTENCY:" in app.activity_heatmap.consistency_badge.text, "Consistency badge text missing!"
    print("Quick-Deploy Quest Terminal and 30-Day Heatmap verified!")

    # 13. Test Sidebar Navigation Completeness (All 13 screens)
    print("\n[TEST 13] Testing Sidebar Navigation Completeness...")
    expected_nav = [
        "home", "focus", "habits", "arcade", "missions", "ai",
        "mood", "achievements", "insights", "roast", "profile",
        "leaderboard", "settings"
    ]
    for page in expected_nav:
        assert page in app.nav_buttons, f"Missing navigation button for '{page}'!"
        assert app.pages.has_screen(page), f"Missing Screen for '{page}'!"
    print("All 13 navigation items and screens verified!")

    # Cleanup test file
    try:
        os.remove(app.data_file)
        if os.path.exists(app.data_file + ".tmp"):
            os.remove(app.data_file + ".tmp")
    except Exception:
        pass

    print("\n" + "=" * 60)
    print("ALL TESTS (13/13) PASSED WITH 100% SUCCESS!")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()

