"""
render_proof_modal.py - Render screenshot of the QuestProofModal in action
"""

import os
import sys
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from kivy.clock import Clock
from kivy.core.window import Window
import main_leaderboard

# Create sample test proof image
sample_img = os.path.join(os.path.dirname(__file__), "sample_proof.png")
im = Image.new("RGB", (640, 480), color=(18, 28, 48))
im.save(sample_img)

# Bypass BootScreen for fast screenshot testing
main_leaderboard.BootScreen = lambda: main_leaderboard.Widget(size_hint=(0, 0))

app = main_leaderboard.ProcrastiNotApp()

def run_test(dt):
    # Remove BootScreen if present
    for child in list(Window.children):
        for sub in list(child.children) if hasattr(child, "children") else []:
            if isinstance(sub, main_leaderboard.NeonKatakanaBoot):
                sub._finish(True)
                if sub in child.children:
                    child.remove_widget(sub)

    # Insert an active quest for the screenshot
    app.missions.insert(0, {
        "name": "Complete Calculus Differential Equations",
        "criteria": "Photo of handwritten workings for problems 1-5",
        "done": False,
        "priority": "High",
        "deadline": "2026-10-20"
    })
    
    # Open proof modal
    app.open_proof_verification(0)
    
    # After opening, stage the image and simulate approved verdict
    def step_stage(dt):
        for w in Window.children:
            if isinstance(w, main_leaderboard.QuestProofModal):
                w.on_image_selected(sample_img)
                # Show mock verification success
                w.on_verification_success({
                    "verdict": "approved",
                    "confidence": 0.96,
                    "reason": "Calculus homework verified with clear visible differential equations.",
                    "evidence_found": [
                        "Legible differential equations on lined notebook paper",
                        "Step-by-step derivative workings shown",
                        "Page header matches assignment syllabus"
                    ],
                    "missing_evidence": []
                })
                break
        
        # Capture screenshot
        def step_snap(dt):
            out_path = os.path.join(os.path.dirname(__file__), "proof_modal_preview.png")
            Window.screenshot(out_path)
            print("Screenshot saved to:", out_path)
            Clock.schedule_once(lambda dt: app.stop(), 0.5)

        Clock.schedule_once(step_snap, 0.4)

    Clock.schedule_once(step_stage, 0.4)

Clock.schedule_once(run_test, 0.5)
app.run()
