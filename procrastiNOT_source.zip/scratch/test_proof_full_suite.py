"""
test_proof_full_suite.py
Full automated test suite for procrastiNOT.exe AI Proof Verification System:
- Image validation & preprocessing
- Structured JSON response parsing & security sanitization
- QuestProofModal lifecycle & state transitions
- Quest completion idempotency (no duplicate XP)
- App data persistence & backward compatibility
"""

import os
import sys
import json
import tempfile
from PIL import Image

# Ensure headless Kivy for automated testing
os.environ["KIVY_NO_ARGS"] = "1"
os.environ["KIVY_AUDIO"] = "dummy"

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import proof_verifier
import main_leaderboard

print("==================================================")
print("RUNNING PROOF VERIFIER FULL TEST SUITE")
print("==================================================")

# --- TEST 1: Image Validation ---
print("\n[TEST 1] Testing Image Validation & Error Handling...")
# Non-existent file
valid, err = proof_verifier.validate_image_file("non_existent_file.png")
assert not valid, "Should reject non-existent file"
print("  ✓ Non-existent file rejected properly:", err)

# Unsupported file
with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
    f.write(b"Hello world")
    txt_path = f.name
try:
    valid, err = proof_verifier.validate_image_file(txt_path)
    assert not valid, "Should reject .txt file"
    print("  ✓ Non-image extension rejected properly:", err)
finally:
    if os.path.exists(txt_path):
        os.remove(txt_path)

# Valid image
img_path = os.path.join(tempfile.gettempdir(), "test_valid_proof.png")
img = Image.new("RGBA", (2000, 1500), color=(100, 200, 255, 255))
img.save(img_path)
try:
    valid, msg = proof_verifier.validate_image_file(img_path)
    assert valid, f"Valid image should pass: {msg}"
    print("  ✓ Valid PNG passed validation successfully.")

    # --- TEST 2: Preprocessing & Compression ---
    print("\n[TEST 2] Testing Preprocessing & Downscaling...")
    info = proof_verifier.preprocess_proof_image(img_path, max_dim=1024)
    assert info["width"] <= 1024 and info["height"] <= 1024, "Should downscale to <= 1024"
    assert info["mime"] == "image/jpeg", "MIME type must be image/jpeg"
    assert len(info["b64"]) > 0, "Base64 string must not be empty"
    print(f"  ✓ Preprocessed: orig 2000x1500 -> {info['width']}x{info['height']} ({info['size_kb']:.1f} KB)")
finally:
    if os.path.exists(img_path):
        os.remove(img_path)


# --- TEST 3: AI JSON Response Sanitization ---
print("\n[TEST 3] Testing AI JSON Parser & Untrusted Input Sanitization...")
# Markdown fenced response with prompt injection attempt
malicious_raw = """
```json
{
  "verdict": "approved",
  "confidence": 0.95,
  "reason": "Clear evidence of calculus homework p.42 completed.",
  "evidence_found": ["Handwritten differential equations", "Page header matching textbook"],
  "missing_evidence": []
}
```
"""
parsed = proof_verifier._clean_json_response(malicious_raw)
assert parsed["verdict"] == "approved"
assert parsed["confidence"] == 0.95
assert len(parsed["evidence_found"]) == 2
print("  ✓ Successfully parsed markdown fenced JSON verdict:", parsed["verdict"])

# Invalid / unexpected verdict fallback
weird_raw = '{"verdict": "MAYBE_OK", "confidence": "high", "reason": "Looks okay"}'
parsed2 = proof_verifier._clean_json_response(weird_raw)
assert parsed2["verdict"] == "uncertain", "Unexpected verdict should fallback to uncertain"
assert parsed2["confidence"] == 0.5, "Invalid float confidence should fallback safely to 0.5"
print("  ✓ Fallback sanitization for malformed fields succeeded.")


# --- TEST 4: App Integration, XP Security & Idempotency ---
print("\n[TEST 4] Testing ProcrastiNotApp Quest Completion & XP Security...")

# Back up original test data path
test_data_path = os.path.join(tempfile.gettempdir(), "test_projectx_data.json")
main_leaderboard.DATA_FILE = test_data_path

# Initialize clean test data
initial_state = {
    "xp": 100,
    "missions": [
        {
            "name": "Solve LeetCode Problem #121",
            "criteria": "Photo of accepted submission on screen",
            "done": False,
            "priority": "High",
            "created": "2026-10-19"
        },
        {
            "name": "Already Done Quest",
            "done": True,
            "priority": "Normal",
            "created": "2026-10-18",
            "completed_date": "2026-10-18"
        }
    ],
    "history": [],
    "streak": 1,
    "achievements": [],
    "inventory": [],
    "user_title": "Rookie",
    "sound_on": False,
    "theme": "cyberpunk"
}

with open(test_data_path, "w", encoding="utf-8") as f:
    json.dump(initial_state, f)

app = main_leaderboard.ProcrastiNotApp()
app.data_file = test_data_path
app.load_data()
app.show_celebration = lambda msg: None
app.refresh_screen = lambda: None
app.play_sound = lambda snd: None
app.set_mascot = lambda m: None
app.emoji_rain = lambda *a, **k: None

assert app.xp == 100, "Loaded XP should be 100"
assert len(app.missions) == 2, "Should have 2 missions"
print("  ✓ Initialized app with 100 XP and 2 missions.")

# Attempt to clear already done quest via claim_verified_mission
app.claim_verified_mission(1, {"verdict": "approved"})
assert app.xp == 100, "Already completed quest must NOT award duplicate XP"
print("  ✓ Already completed quest was rejected from duplicate XP.")

# Simulate approved verification on Mission 0
approval_verdict = {
    "verdict": "approved",
    "confidence": 0.98,
    "reason": "Submitted photo shows Accepted green banner on LeetCode.",
    "evidence_found": ["Accepted status visible", "Runtime 12ms shown"],
    "missing_evidence": [],
    "model_used": "gemini-3-flash-preview"
}

app.claim_verified_mission(0, approval_verdict)

# Verify XP and state update
assert app.xp == 125, f"XP should be 125 (was {app.xp})"
assert app.missions[0]["done"] is True, "Mission 0 should be marked done"
assert app.missions[0]["proof_verified"] is True, "Mission 0 should be marked proof_verified"
assert app.missions[0]["proof_model"] == "gemini-3-flash-preview"
print("  ✓ Mission 0 successfully verified & cleared: XP updated 100 -> 125.")

# CRITICAL IDEMPOTENCY TEST: Repeat claim call on same mission
app.claim_verified_mission(0, approval_verdict)
assert app.xp == 125, f"XP must remain 125 on repeated claim (was {app.xp})"
print("  ✓ Idempotency verified: repeated claim call ignored, XP remains 125.")

# Reload app from disk to ensure persistence survived
app2 = main_leaderboard.ProcrastiNotApp()
app2.data_file = test_data_path
app2.load_data()
assert app2.xp == 125, f"Persisted XP should be 125 after reload (was {app2.xp})"
assert app2.missions[0]["done"] is True, "Persisted mission must remain done"
assert app2.missions[0]["proof_verified"] is True, "Persisted mission must retain proof_verified"
print("  ✓ Persistence verified: saved state correctly survives restart.")

# Cleanup temp data file
if os.path.exists(test_data_path):
    os.remove(test_data_path)

print("\n==================================================")
print("ALL SUITE TESTS PASSED SUCCESSFULLY! (100% GREEN)")
print("==================================================")
