"""
render_companion_screens.py
Renders screenshots of:
1. Living Companion active in the sidebar under RANKS & SETTINGS
2. "CHOOSE YOUR OPERATOR" selection modal
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

from kivy.config import Config
Config.set('graphics', 'width', '1120')
Config.set('graphics', 'height', '720')
from kivy.clock import Clock
from kivy.core.window import Window
Window.size = (1120, 720)
import main_leaderboard
import companion

# Bypass boot screen for immediate visual capture
main_leaderboard.BootScreen = lambda: main_leaderboard.Widget(size_hint=(0, 0))

app = main_leaderboard.ProcrastiNotApp()
# Set active companion to NEX for the main view
app.selected_companion = "nex"

def run_capture(dt):
    # Step 1: Capture Main Dashboard with Companion in sidebar
    def step_dashboard(dt):
        out_dash = os.path.join(os.path.dirname(__file__), "companion_sidebar_preview.png")
        Window.screenshot(out_dash)
        print("Captured Dashboard to:", out_dash)

        # Step 2: Open Operator Selection Modal
        def step_modal(dt):
            app.open_companion_selector(force=True)

            def step_snap_modal(dt):
                out_modal = os.path.join(os.path.dirname(__file__), "operator_select_modal_preview.png")
                Window.screenshot(out_modal)
                print("Captured Operator Modal to:", out_modal)
                Clock.schedule_once(lambda dt: app.stop(), 0.5)

            Clock.schedule_once(step_snap_modal, 0.4)

        Clock.schedule_once(step_modal, 0.5)

    Clock.schedule_once(step_dashboard, 0.5)

Clock.schedule_once(run_capture, 0.6)
app.run()
